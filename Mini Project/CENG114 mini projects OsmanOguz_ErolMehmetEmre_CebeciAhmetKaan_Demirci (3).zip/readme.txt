Group members:

Osman Oğuz Erol
22050111048

Mehmet Emre Cebeci
21050111037

Ahmet Kaan Demirci
21050111031